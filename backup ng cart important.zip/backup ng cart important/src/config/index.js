import db from "./db.json";

export const firebaseConfig = db;
