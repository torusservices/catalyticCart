import { firebaseConfig } from '../config';

export const environment = {
  production: true,
  firebase: firebaseConfig,
};
